// ---------- CHARTS ----------

// LINE CHART
const lineChartOptions = {
    series: [
      {
        name: 'Energy Production (kWh)',
        data: [25, 32, 18, 40, 35, 50, 42],
      },
    ],
    chart: {
      type: 'line',
      height: 350,
      toolbar: {
        show: false,
      },
    },
    colors: ['#246dec'],
    dataLabels: {
      enabled: false,
    },
    stroke: {
      curve: 'smooth',
    },
    xaxis: {
      categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    },
    yaxis: {
      title: {
        text: 'Energy (kWh)',
      },
    },
  };
  
  const lineChart = new ApexCharts(
    document.querySelector('#line-chart'),
    lineChartOptions
  );
  lineChart.render();

// DONUT CHART
const donutChartOptions = {
    series: [45, 35, 20],
    chart: {
      type: 'donut',
      height: 350,
    },
    labels: ['Panel 1', 'Panel 2', 'Panel 3'],
    colors: ['#246dec', '#cc3c43', '#367952'],
    dataLabels: {
      enabled: true,
      formatter: function (val) {
        return val + '%';
      },
    },
    legend: {
      show: false,
    },
  };

  const donutChart = new ApexCharts(
    document.querySelector('#donut-chart'),
    donutChartOptions
  );
  donutChart.render();

  // AREA CHART
  const areaChartOptions = {
    series: [
      {
        name: 'Energy Production',
        data: [31, 40, 28, 51, 42, 109, 100],
      },
      {
        name: 'Energy Consumption',
        data: [11, 32, 45, 32, 34, 52, 41],
      },
    ],
    chart: {
      height: 350,
      type: 'area',
      toolbar: {
        show: false,
      },
    },
    colors: ['#246dec', '#cc3c43'],
    dataLabels: {
      enabled: false,
    },
    stroke: {
      curve: 'smooth',
    },
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
    markers: {
      size: 0,
    },
    yaxis: [
      {
        title: {
          text: 'Energy (kWh)',
        },
      },
    ],
    tooltip: {
      shared: true,
      intersect: false,
    },
  };
  
  const areaChart = new ApexCharts(
    document.querySelector('#area-chart'),
    areaChartOptions
  );
  areaChart.render();