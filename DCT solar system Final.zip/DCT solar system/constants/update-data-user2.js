const UPDATE_DATA = [
    {
      imgSrc: "./images/solar.webp", // Replace with actual image
      profileName: "DCT Solar Team",
      message: "Your solar system is performing optimally! You've generated 12kWh of clean energy today.",
      updatedTime: "Today",
    },
    {
      imgSrc: "./images/solar.webp", // Replace with actual image
      profileName: "DCT Solar Team",
      message: "Your system monitoring report is ready! Check your inbox for detailed insights.",
      updatedTime: "Yesterday",
    },
    {
      imgSrc: "./images/solar.webp", // Replace with actual image
      profileName: "DCT Solar Team",
      message: "Reminder: Your next system maintenance is scheduled for 2024-05-15. A technician will contact you soon.",
      updatedTime: "Last Week",
    },
  ];