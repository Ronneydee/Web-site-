const SALES_ANALYTICS_DATA = [
    {
      itemClass: "online",
      icon: "shopping_cart",
      title: "Solar Panels",
      colorClass: "success",
      percentage: "+22",
      sales: "R4500",
    },
    {
      itemClass: "offline",
      icon: "local_mall",
      title: "Batteries",
      colorClass: "warning",
      percentage: "-5",
      sales: "R1800",
    },
    {
      itemClass: "customers",
      icon: "person",
      title: "Inverters",
      colorClass: "success",
      percentage: "+15",
      sales: "R950",
    },
  ];