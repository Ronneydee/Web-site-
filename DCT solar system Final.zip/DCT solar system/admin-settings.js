document.addEventListener('DOMContentLoaded', () => {
    // Mocked current user data
    const currentUser = {
        profilePicture: './images/profile-3.jpg',
        name: 'Tafadzwa',
        email: 'admin@dct-solar.co.za'
    };

    // Populate form with current user data
    const profilePictureInput = document.getElementById('profile-picture');
    const currentProfilePicture = document.getElementById('current-profile-picture');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');

    // Display current profile picture
    if (currentUser.profilePicture) {
        currentProfilePicture.src = currentUser.profilePicture;
        currentProfilePicture.style.display = 'block';
    }

    // Populate input fields
    nameInput.value = currentUser.name;
    emailInput.value = currentUser.email;

    // Form submission handler
    const form = document.getElementById('edit-profile-form');
    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const formData = new FormData(form);

        // Mocked form submission
        console.log('Profile Picture:', formData.get('profile-picture'));
        console.log('Name:', formData.get('name'));
        console.log('Email:', formData.get('email'));
        console.log('Password:', formData.get('password'));
        console.log('Confirm Password:', formData.get('confirm-password'));

        // Here you can add your logic to update the user data, e.g., make an API call
        alert('Profile updated successfully!');
    });

    // Preview selected profile picture
    profilePictureInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                currentProfilePicture.src = reader.result;
                currentProfilePicture.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });
});
